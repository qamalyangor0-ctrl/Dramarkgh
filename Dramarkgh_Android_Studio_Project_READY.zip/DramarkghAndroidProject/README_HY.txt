DRAMARKGH — Android APK

Այս նախագիծը Dramarkgh վեբ հավելվածը փաթեթավորում է որպես սովորական Android հավելված։
AWebServer այլևս անհրաժեշտ չէ․ հավելվածը բեռնում է index.html-ը APK-ի ներսից։
Տվյալների համար WebView-ի DOM storage-ը միացված է։

APK ստանալու ամենահեշտ եղանակը հեռախոսով՝ GitHub Actions.

1. GitHub-ում ստեղծիր նոր դատարկ repository։
2. ZIP-ը բացիր և repository-ի մեջ վերբեռնիր ամբողջ DramarkghAndroidProject պանակի պարունակությունը։
3. Վերբեռնելուց հետո մտիր Actions բաժին։
4. Ընտրիր «Build Dramarkgh APK» workflow-ը և սեղմիր Run workflow։
5. Ավարտվելուց հետո բացիր workflow-ի արդյունքը, Artifacts բաժնում ներբեռնիր «Dramarkgh-APK»։
6. ZIP-ը բացիր և տեղադրիր app-debug.apk-ը հեռախոսում։

Եթե push անես main branch, APK-ի build-ը նույնպես ավտոմատ կաշխատի։
